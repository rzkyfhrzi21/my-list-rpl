<?php
header('Location: ../index');
