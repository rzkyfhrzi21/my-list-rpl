<?php
define("NAMA_WEB", "To Do List");
define("NAMA_LENGKAP", "Adinata");
define("IG", "lailansvh");
define("EMAIL", "lailanurmasv@gmail.com");
define("NO_WA", "085162642703");
define("MATKUL", "Rekayasa Perangkat Lunak");
define("URL_IG", "https://www.instagram.com/lailansvh");
define("URL_WA", "https://api.whatsapp.com/send/?phone=6285173200421");
define("NAMA_KAMPUS", "IIB Darmajaya");
define("MAPS_KAMPUS", "https://maps.app.goo.gl/MDRbHF1mJTq81Ec67");
