<?php
include 'functions/config.php';

$now = date('Y-m-d H:i:s');

$sql_notif = mysqli_query(
    $koneksi,
    "SELECT 
        id_task,
        name,
        description,
        category,
        priority,
        status,
        deadline,
        reminder,
        DATEDIFF(DATE(deadline), CURDATE()) AS sisa_hari
     FROM tasks
     WHERE id_user = '$sesi_id'
       AND status = 'belum'
       AND deadline IS NOT NULL
       AND DATE(deadline) <= CURDATE()
     ORDER BY deadline ASC
     LIMIT 1"
);

$status_notif = mysqli_fetch_assoc($sql_notif);
?>

<?php if (!empty($status_notif)) : ?>

    <?php
    // Penentuan badge & pesan
    if ($status_notif['sisa_hari'] < 0) {
        $alertClass = 'danger';
        $title      = '⛔ Deadline Terlewat!';
        $message    = 'Tugas ini telah melewati batas waktu pengerjaan.';
    } elseif ($status_notif['sisa_hari'] == 0) {
        $alertClass = 'warning';
        $title      = '⚠️ Deadline Hari Ini';
        $message    = 'Tugas ini harus diselesaikan hari ini.';
    } else {
        $alertClass = 'info';
        $title      = '📌 Pengingat Tugas';
        $message    = 'Tugas memiliki deadline terdekat.';
    }
    ?>

    <div class="card mb-3">
        <div class="card-body">
            <div class="alert alert-<?= $alertClass; ?> mb-0">

                <h4 class="alert-heading"><?= $title; ?></h4>

                <p><?= $message; ?></p>

                <hr>

                <p class="mb-1">
                    <b>📄 Nama Task:</b> <?= htmlspecialchars($status_notif['name']); ?>
                </p>

                <?php if (!empty($status_notif['description'])) : ?>
                    <p class="mb-1">
                        <b>📝 Deskripsi:</b> <?= htmlspecialchars($status_notif['description']); ?>
                    </p>
                <?php endif; ?>

                <p class="mb-1">
                    <b>📂 Kategori:</b> <?= htmlspecialchars($status_notif['category'] ?? '-'); ?>
                </p>

                <p class="mb-1">
                    <b>⏰ Deadline:</b>
                    <?= date('d M Y H:i', strtotime($status_notif['deadline'])); ?>
                </p>

                <?php if (!empty($status_notif['reminder'])) : ?>
                    <p class="mb-1">
                        <b>🔔 Reminder:</b>
                        <?= date('d M Y H:i', strtotime($status_notif['reminder'])); ?>
                    </p>
                <?php endif; ?>

                <p class="mb-2">
                    <b>🚦 Prioritas:</b>
                    <span class="badge bg-<?=
                                            $status_notif['priority'] == 'tinggi' ? 'danger' : ($status_notif['priority'] == 'sedang' ? 'warning' : 'primary'); ?>">
                        <?= ucfirst($status_notif['priority']); ?>
                    </span>
                </p>

                <a href="?page=task" class="btn btn-sm btn-outline-dark">
                    <i class="bi bi-eye"></i> Lihat Task
                </a>

            </div>
        </div>
    </div>

<?php endif; ?>